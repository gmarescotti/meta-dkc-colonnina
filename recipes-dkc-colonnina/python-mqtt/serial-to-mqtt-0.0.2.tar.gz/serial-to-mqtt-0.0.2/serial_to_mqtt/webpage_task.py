"""
read commands issued by "issue_command.sh" cgi script triggered
by nginx engine.
"""

import asyncio
from ipyc import AsyncIPyCHost, AsyncIPyCLink
import datetime
import logging
import json
import struct

from general_message import GeneralCommands

log = logging.getLogger("root.webpage")

# Sub command identifier
SERIAL_MESSAGE_SUBCOMMAND_WEBPAGE_SWIPE_RFID = 9000
SERIAL_MESSAGE_SUBCOMMAND_WEBPAGE_ADD_RFID = 9001
SERIAL_MESSAGE_SUBCOMMAND_WEBPAGE_REMOVE_RFID = 9002
SERIAL_MESSAGE_SUBCOMMAND_WEBPAGE_UPDATE_ALL_RFIDS = 9003
SERIAL_MESSAGE_SUBCOMMAND_REMOVE_ALL_RFIDS = 9004
SERIAL_MESSAGE_SUBCOMMAND_CHECK_EMPTY_RFID_STORAGE = 9005

SERIAL_MESSAGE_SUBCOMMAND_ACK_RESET_FACTORY_DEFAULT = 9006

from serial_protocol import SERIAL_MESSAGE_COMMAND
import sql.mydb

code_names = {
        7000: "startup-dsp-gostandby",
        7001: "stop-dsp-go-waitforstart",
        9000: "swipe-rfid-please",
        9001: "add-rfid",
        9004: "remove-all-rfid",
        9005: "check-empty-rfid",
        }

# ====================================================
# exclude ExtendCommands, new management for dynamic structure
# not using cstruct.Cstruct
class WebpageCommandsMessage(GeneralCommands):
    # __struct__ = """
    #         uint32_t command_id;    //! command identifier
    #         uint32_t command_params[5]; //! optional info specific to the command [optional]
    # """
    # topicname="webpagecommands"
    id=SERIAL_MESSAGE_COMMAND

    def __init__(self, connection, command_id, command_params=[]): # command_id, command_params):
        self.command_id = command_id
        self.command_params = command_params
        self.connection = connection
        self.content = struct.pack("L", self.command_id)
        if type(command_params) == bytes:
            self.content += self.command_params
        elif type(command_params) == list:
            self.content += struct.pack(f"{len(self.command_params)}L", *self.command_params)
        else:
            assert False, "???"

    async def response_callback(self, response):
        log.debug (f"response_callback: sending back {response}...")
        await self.connection.send(response)

    def __str__(self):
       # orig: AckCommandsMessage(command_id=7000, command_params=[])
       return f"Send Command[{self.mp_last_message_counter}] {self.command_id}: {code_names.get(self.command_id, str(self.command_id))}, with params: {self.command_params}"

async def webpage_task(serial_queue):
   host = AsyncIPyCHost()
   @host.on_connect
   async def on_client_connect(connection: AsyncIPyCLink):
       while connection.is_active():
           message = await connection.receive()
           if message:
               log.debug(f"[{datetime.datetime.now()}] - Client says: {message}")
               command_args = json.loads(message)
               log.info(f"issue_command_to_dsp: {command_args}")
               keys = list(command_args.keys())
               keys.sort()
               if keys == ['command_id', 'command_params']:
                   # transform ultra long number (ie rfid) in array of longs
                   try:
                       msg = WebpageCommandsMessage(connection, **command_args)
                   except Exception as e:
                       log.exception("webpage_task: during instantiation of a new message..")
                       await connection.send(str(e))
                       continue
                   serial_queue.put_nowait(msg)
               else:
                   log.error(f"Message not understood: {message}")
           else:
               # log.error(f"message empty?? '{message}'")
               pass # here when closing connection?
       log.debug(f"[{datetime.datetime.now()}] - Connection was closed!")

       # reschedule
       # await host.start()

   log.info("starting webpage_task...")
   await host.start()

"""
called by signals:
    killall -SIGUSR1 python3
    pkill -SIGUSR1 -F /var/run/serial_to_mqtt
"""
def manage_signals(*args):
    global log
    log.info("manage_signals: signal managed => %s" % args)

if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG)
    loggers = [logging.getLogger(name) for name in logging.root.manager.loggerDict]
    for logger in loggers: logger.setLevel(logging.DEBUG)
    # test len string con cstruct
    msg = WebpageCommandsMessage(command_id = 33, command_params = [0x102030], connection=None)
    # msg = WebpageCommandsMessage(command_id = 33, param = b"")


    print (msg.pack())
    print (msg)

