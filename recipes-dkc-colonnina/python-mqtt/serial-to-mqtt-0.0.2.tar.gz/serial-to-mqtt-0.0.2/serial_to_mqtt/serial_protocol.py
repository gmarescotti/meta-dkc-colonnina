import json
import datetime, pytz
import os
import bitstruct
import struct
import cstruct
import logging
# import uuid
import getmac

from enum import IntEnum

from .serial_enumerations import SerialEvent, MqttEvent
from .webpage_params import update_info_params
from .general_message import ResponseMessage
import mydb
import scramble

from mydecorator import MyDecorator

log     = logging.getLogger("root.serial")
logmqtt = logging.getLogger("root.mqtt")
logweb  = logging.getLogger("root.webpage")

"""

 serial message format
 it composed by a common header and a
 body specific to the message type
 listed below

"""

""""
 all data part of configuration are stored here
"""
# > this info come from DSP
# class configuration:
#     maximum_power=22000 # [watt]
#     nominal_power=22000 # [watt]
#     monofase=False


# MESSAGE TYPES
SERIAL_MESSAGE_INCOMPLETE=0
# TX: DSP => MICROCHIP
SERIAL_MESSAGE_EVENT=10
SERIAL_MESSAGE_TELEMETRY=1
SERIAL_MESSAGE_SYSTEM_INFO=4
SERIAL_MESSAGE_RESPONSE=5
SERIAL_MESSAGE_JUST_SWIPED_RFID_CODE=6
# RX: MICROCHIP => DSP
SERIAL_MESSAGE_COMMAND=2
# SERIAL_MESSAGE_COMMAND_WEBPAGE=3

def get_uptime():
    with open('/proc/uptime', 'r') as f:
        uptime_seconds = float(f.readline().split()[0])

    return uptime_seconds

# ====================================================
"""
  serial message SERIAL_MESSAGE_EVENT
  contains an EVENT data
"""
class EventMessage(MyDecorator, cstruct.CStruct):
    topicname="events"
    __byte_order__ = cstruct.LITTLE_ENDIAN
    __struct__ = """
            uint16_t event_id;  //! event identifier (origin was "alarm_id_t error")
            int16_t alarm_param;//! optional info specific to the event [optional]
    """

    def __init__(self, serial_queue):
        self.serial_queue = serial_queue

    def unpack(self, content):
        cstruct.CStruct.unpack(self, content)
        self.run_command(5000+self.event_id, self.alarm_param)

    def as_dict(self):
        event = SerialEvent(self.event_id)
        # param = event.describe(self.alarm_param)
        mqtt_event = event.toMqttEvent(self.alarm_param)
        if mqtt_event is None: 
            return None

        timestamp = int(datetime.datetime.now(pytz.timezone('Europe/Rome')).timestamp())

        return {timestamp: mqtt_event.value}

    def __str__(self):
        return f"EventMsg(event_id={SerialEvent(self.event_id).name}, alarm_param={self.alarm_param})"

# ====================================================
"""
  serial message SERIAL_MESSAGE_TELEMETRY
  contains a TELEMETRY data
"""
class TelemetryMessage(cstruct.CStruct):
    topicname="telemetry"
    __byte_order__ = cstruct.LITTLE_ENDIAN
    __struct__ = """
           uint32_t worktime;               // time since the user logon (rfid swipe)
           float domestic_power;            // power draws by the domestic loads
           float wallbox_power;             // power draws by the vehicle
           float wallbox_current;           // current on the vehicle plug
           float wallbox_voltage;           // voltage on the vehicle plug
           float last_charge_cycle_energy;  // energy used on the last charge cycle
           float temperature;               // [degree]
           uint16_t wallbox_state;
           uint16_t active_user[10];        // uid of the active user
           uint16_t padding;                // alignment is 32 bit (texas instruments?)
    """

    def as_dict(self):
        # timestamp = int(time.time())
        timestamp = int(datetime.datetime.now(pytz.timezone('Europe/Rome')).timestamp())
        # let DSP calculate worktime (once was the linux worktime => self.worktime = get_uptime())

        ret = {timestamp: {
            2000: self.domestic_power,           # Potenza carichi domestici
            2001: self.wallbox_power,            # Potenza wallbox
            2002: self.wallbox_current,          # Corrente wallbox
            2003: self.wallbox_voltage,          # Tensione wallbox
            2004: self.active_user,              # Utente attivo
            2005: self.worktime,                   # Work time
            2006: self.last_charge_cycle_energy, # Energia ciclo di ricarica
            2007: self.temperature,              # Temperatura
            2008: self.wallbox_state}}           # Stato wallbox

        return ret

# ====================================================
"""
  serial message SERIAL_MESSAGE_JUST_SWIPED_RFID_CODE
  contains a JUST_SWIPED_RFID_CODE data
"""
class SwpiedRfidCodeMessage(cstruct.CStruct):
    topicname="justswipedrfidcode"
    __byte_order__ = cstruct.LITTLE_ENDIAN
    __struct__ = """
        uint16_t size;			// Number of bytes in the UID. 4, 7 or 10.
        uint16_t uidbyte[10];
    """

    async def react(self):
        hex_code = self.uidbyte[:self.size]
        byte_code = b"".join((d).to_bytes(1, byteorder='big') for d in hex_code)
        crypt_code = scramble.encrypt(byte_code)
        hex_code_str = ":".join(["{:02x}".format(x) for x in hex_code])
        log.debug(f"Swiped new RFID card: [{hex_code_str}], scramble={crypt_code}, byte_code={byte_code.hex()}")
        # TODO: add SQL INSERT ...
        mydb.db_add_card(crypt_code.hex())

# ====================================================
"""
  serial message SERIAL_MESSAGE_SYSTEM
  contains a SYSTEM data
"""
class SystemInfoMessage(cstruct.CStruct):
    topicname="system"
    __byte_order__ = cstruct.LITTLE_ENDIAN
    __struct__ = """
           float wallbox_rated_power;       // Potenza di targa
           uint32_t meter_power_rating;     // Potenza nominale da contatore
           uint16_t facility_configuration; // Configurazione macchina 1 Byte bitfield
           uint16_t wallbox_type;           // Tipologia wallbox 1 Byte bitfield
    """

    def __init__(self):
        self.timestamp = int(datetime.datetime.now(pytz.timezone('Europe/Rome')).timestamp())

        try:
            self.ipv4 = os.popen('ip addr show eth0').read().split("inet ")[1].split("/")[0]
        except:
            self.ipv4 = "not available"
        try:
            self.ipv4_wlan = os.popen('ip addr show wlan0').read().split("inet ")[1].split("/")[0]
        except:
            self.ipv4_wlan = "not available"
        try:
            self.ipv6 = os.popen('ip addr show eth0').read().split("inet6 ")[1].split("/")[0]
        except:
            self.ipv6 = "not available"

        """
        calcolo mac address
        """
        # self.macaddress = (uuid.getnode()).to_bytes(6, byteorder='big').hex(":") # MAC address
        self.macaddress = getmac.get_mac_address("eth0")

    def as_dict(self):
        ret = {self.timestamp: {
            1000: self.macaddress,              # MAC address
            1001: 1,                            # ID impianto
            1002: "dkc",                        # costruttore;
            1003: self.facility_configuration,  # configurazione_macchina;
            1004: self.meter_power_rating,      # potenza_nominale_da_contatore;
            1005: 0,                            # indirizzo_device_modbus;
            1006: self.ipv4,                    # indirizzo_ip_locale_lan;
            1007: self.ipv4_wlan,               # indirizzo_ip_wlan;
            1008: self.timestamp,               # data_ora_epoch;
            1009: "it-IT",                      # lingua;
            1010: 5,                            # frequenza_invio_valori_real_time; [sec]
            1015: self.wallbox_type,            # tipologia_wallbox;
            1016: 0x01020304,                   # id_wallbox;
            1017: 0x01020304,                   # num_serial;
            1018: 0x010000,                     # versione_firmware;
            1019: 0x010000,                     # versione_software;
            1020: self.wallbox_rated_power   # potenza_di_targa;
            }}

        update_info_params(ret)

        return ret


    # def __str__(self): return str(self.__dict__)

# ====================================================
async def get_serial_message(reader, serial_queue):

    length = int.from_bytes(await reader.readexactly(2), "little")
    command_id = int.from_bytes(await reader.readexactly(2), "little")
    log.debug(f"get_serial_message: length={length}, command_id={command_id}")

    if command_id == SERIAL_MESSAGE_RESPONSE:
        message = ResponseMessage()
    elif command_id == SERIAL_MESSAGE_TELEMETRY:
        message = TelemetryMessage()
    elif command_id == SERIAL_MESSAGE_EVENT:
        message = EventMessage(serial_queue)
    elif command_id == SERIAL_MESSAGE_SYSTEM_INFO:
        message = SystemInfoMessage()
    elif command_id == SERIAL_MESSAGE_JUST_SWIPED_RFID_CODE:
        message = SwpiedRfidCodeMessage()
    else:
        # assert False, f"Unknown header type: {header}"
        log.error(f"Unknown command_id {hex(command_id)} (length={hex(length)})!")
        return None

    line = await reader.readexactly(length-4)

    log.debug(f"Arrivato: {line.hex()}")
    message.unpack(line)

    log.debug(f"{message.__class__.__name__} received: {message}")
    return message

if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG)
    loggers = [logging.getLogger(name) for name in logging.root.manager.loggerDict]
    for logger in loggers: logger.setLevel(logging.DEBUG)

    e = EventMessage()
    e.event_id=12
    e.alarm_param=0xf

    print(e)
    print(e.pack().hex())
