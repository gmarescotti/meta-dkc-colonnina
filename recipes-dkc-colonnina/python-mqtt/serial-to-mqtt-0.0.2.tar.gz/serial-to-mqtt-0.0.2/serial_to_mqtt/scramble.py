import xxtea

encryptionKey = (0x66C5FDCD478455B0D19E0B7E6CB2A811).to_bytes(16, byteorder='big')

def encrypt(data):
    data = (len(data)).to_bytes(1, byteorder='big') + data
    data = data.ljust(12, b'\0')
    encrypted_data = xxtea.encrypt(data=data, key=encryptionKey, rounds=12, padding=False)
    return encrypted_data

def decrypt(data):
    decrypted_data = xxtea.decrypt(data=data, key=encryptionKey, rounds=12, padding=False)
    length=int.from_bytes(decrypted_data[:1], byteorder='big')
    # print(f"LENGTH={hex(length)}")
    return decrypted_data[1:length+1]

if __name__=='__main__':
    def test(data):
        print(f"data={data}, lenght={len(data)}")
        encr = encrypt(data)
        print(f"encr={encr.hex()}, length={len(encr)}")
        decr = decrypt(encr)
        print(f"decr={decr.hex()}, length={leni(decr)}")
        print()
    
        test(b"cinqu")
        test(b"setttte")
        test(b"diieecciii")
    
    # >>> hex(16659969002634179069535023770)
    # length, decr = decrypt((0x35d4cda94f52c963e107729a).to_bytes(12, byteorder='big'))

    decr = decrypt((0x2fd872e3d39416ef274518d9).to_bytes(12, byteorder='big')) # DEMO RUSSIA 1
    print("DEMO RUSSIA #1: ", len(decr), decr.hex())

    decr = decrypt((0x92edb2b6c951776e930ddaff).to_bytes(12, byteorder='big')) # DEMO RUSSIA 1
    print("DEMO RUSSIA #2: ", len(decr), decr.hex())

    decr = decrypt((0x4660ffa6da0cb55725de4142).to_bytes(12, byteorder='big')) # DEMO RUSSIA 1
    print("DEMO RUSSIA #3: ", len(decr), decr.hex())

    decr = decrypt((0x600a15a7d94a629a9746a63a).to_bytes(12, byteorder='big')) # DEMO RUSSIA 1
    print("TEST: ", len(decr), decr.hex())

