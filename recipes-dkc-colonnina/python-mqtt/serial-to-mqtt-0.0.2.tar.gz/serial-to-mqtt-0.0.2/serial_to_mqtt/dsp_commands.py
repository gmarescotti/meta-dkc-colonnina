import logging, os
from .mydecorator import MyDecorator
from .general_message import AckCommandsMessage
from .webpage_task import WebpageCommandsMessage
import mydb
import asyncio

event=MyDecorator.command

log = logging.getLogger("root.commands")

async def send_command_wait_ack(serial_queue, id, command_params=[]):
   global log

   class SendCommandsMessage(WebpageCommandsMessage):
       async def response_callback(self, response):
           log.debug (f"response to {self.command_id}: sent back {response}...")
           self.connection.set()
           self.response = response

   flag = asyncio.Event()
   msg = SendCommandsMessage(connection=flag, command_id=id, command_params=command_params) # CHECK_EMPTY_RFID_STORAGE
   serial_queue.put_nowait(msg)
   await flag.wait()
   return msg.response

async def sync_rfid(serial_queue):
   # CHECK RFID STORAGE IF EMPTY: 9005
   if await send_command_wait_ack(serial_queue, 9005) != "RESPONSE_MESSAGE_OK": # Not ok, not empty
       # REMOVE ALL RFID: 9004
       if await send_command_wait_ack(serial_queue, 9004) != "RESPONSE_MESSAGE_OK": # Not ok, something nasty happened, pretent it is ok and proceed
           log.fatal("REMOVE all rfid failed!")

   for encr, decr in mydb.db_get_all_cards():
       log.debug(f"adding rfid encr={encr.hex()}, decr= {decr.hex()}...")
       # AGGIUNGI_RFID = 9001,
       if await send_command_wait_ack(serial_queue, 9001, command_params=decr) != "RESPONSE_MESSAGE_OK":
           log.error(f"add rfid {encr.hex()} {decr.hex()} failed!")

async def startup_routine(serial_queue):
   global log
   # 7000: start command: DSP go to standby
   if await send_command_wait_ack(serial_queue, 7000) != "RESPONSE_MESSAGE_OK": # DSP off ?
       # ok DSP is running, sync rfid
       log.warning("DSP not answering 7000!")
   else:
       await sync_rfid(serial_queue)

@event(5001)
def begin_main_loop(event, alarm_param):
    log.info("INFO_BEGIN_MAIN_LOOP: Begin Main Loop")
    asyncio.create_task(startup_routine(event.serial_queue))

@event(5028)
def reset_factory_default(event, alarm_param):
    # THIS IS THE ACK 
    msg = AckCommandsMessage(1)
    event.serial_queue.put_nowait(msg)

    log.error("Reset Factory Default")
    os.system("/usr/lib/cgi-bin/reset_factory_default.sh")

