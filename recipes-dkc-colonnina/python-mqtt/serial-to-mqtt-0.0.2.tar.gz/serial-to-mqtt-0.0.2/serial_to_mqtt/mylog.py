import os
import logging
import logging.config, os.path
from ruamel import yaml
from glob import glob

def merge(source, destination):
    """
    run me with nosetests --with-doctest file.py

    >>> a = { 'first' : { 'all_rows' : { 'pass' : 'dog', 'number' : '1' } } }
    >>> b = { 'first' : { 'all_rows' : { 'fail' : 'cat', 'number' : '5' } } }
    >>> merge(b, a) == { 'first' : { 'all_rows' : { 'pass' : 'dog', 'fail' : 'cat', 'number' : '5' } } }
    True
    """
    for key, value in source.items():
        if isinstance(value, dict):
            # get node or create one
            node = destination.setdefault(key, {})
            merge(value, node)
        elif isinstance(value, list):
            destination[key] += value
        else:
            destination[key] = value

    return destination

def init_log():
   global log, logmqtt, loghttp

   # load main log configuration
   with open(os.path.join(os.path.dirname(__file__), 'logging_configuration.yaml'), 'rt') as file:
       config = yaml.safe_load(file.read())
       # apply dorollover over file log (not able to set inside conf file!)
       if os.path.exists(config['handlers']['file']['filename']): _dorollover = True

   # load customized secondary log configuration
   # it is possible to add these utility log configurations outside git 
   # for debugging purposes
   for f in glob(os.path.join(os.path.dirname(__file__), './logging_configuration.yaml.*')):
       with open(os.path.join(os.path.dirname(__file__), f), 'rt') as file:
           config2 = yaml.safe_load(file.read())
           config = merge(config2, config)

   logging.config.dictConfig(config)

   log = logging.getLogger()

   try:
      dtgrm_log = next(filter(lambda x: isinstance(x, logging.handlers.DatagramHandler), log.handlers))
   except:
       log.warning("No logger for cutelog in: %s!" % log.handlers)
   else:
      log.info(f"Logging to {dtgrm_log.host}:{dtgrm_log.port}")

   # loggers = [logging.getLogger(name) for name in logging.root.manager.loggerDict]
   # for logger in loggers: logger.setLevel(logging.DEBUG)

init_log()
