# import mylog, logging
# 
# log = logging.getLogger()
# logmqtt = logging.getLogger("root.mqtt")
# loghttp = logging.getLogger("root.http")

# import logging
#import logging.config, os.path

from asyncio_mqtt import Client, MqttError
import asyncio
import aiohttp
import urllib, urllib.parse
#import os
import sys
# import uuid
import getmac
# import traceback
from signal import SIGINT, SIGTERM, SIGUSR1, SIGUSR2

import json

from serial_asyncio import open_serial_connection, serial
from .webpage_params import get_updated_telemetry_params
from .serial_protocol import get_serial_message
from .commands import CommandsMessage
from .webpage_task import webpage_task, manage_signals
from .dsp_commands import startup_routine, send_command_wait_ack

BROKER="213.92.93.75"
#BROKER="79.7.202.167"
#BROKER="test.mosquitto.org"

# MAC_ADDRESS = (uuid.getnode()).to_bytes(6, byteorder='big').hex(":") # MAC address
MAC_ADDRESS = getmac.get_mac_address("eth0")

serial_queue = None

# Test Command:
"""
mosquitto_pub -h "79.7.202.167" -t "DKC/00:00:00:00:00:00/telemetry" -q 1 -m '{'1630930231': {'2000': 0.0, '2001': 0.0, '2002': 0.0, '2003': 0.0, '2004': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0], '2005': 6, '2006': 100.0, '2007': 32.330875396728516, '2008': 9}}'
"""

async def subscriber(client):
   global logmqtt
   global serial_queue
   # async with client.filtered_messages("accumulo/+/algor") as messages:
   async with client.filtered_messages(f"DKC/{MAC_ADDRESS}/#") as messages:
      await client.subscribe(f"DKC/{MAC_ADDRESS}/#")
      async for message in messages:
         if message.topic == f"DKC/{MAC_ADDRESS}/commands":
            payload_str = message.payload.decode()
            payload_commands = json.loads(payload_str)
            for command_id, command_param in payload_commands.items():
               msg = CommandsMessage(command_id=int(command_id), command_params=[int(command_param or 0)])
               serial_queue.put_nowait(msg)
               # logmqtt.debug("GGGGGG" + msg.pack().hex())

         # because subscribed to all topics,
         # all MqTT messages comes here (even myself messages...)
         #logmqtt.debug("loopbacked MQTT message %s" % payload_command)

   logmqtt.debug("fine subscriber")

async def publisher(client, mqtt_queue):
   global log
   while True:
      # message = dict(rgm=i, dkc=99.1)
      message = await mqtt_queue.get()
      payload_as_dict=message.as_dict()
      if payload_as_dict:
         log.debug("publisher: publish %s" % payload_as_dict)
         await client.publish(
               f"DKC/{MAC_ADDRESS}/{message.topicname}",
               payload=json.dumps(payload_as_dict), # .encode()
               timeout=3
               )

         if message.topicname == "telemetry":
            data = get_updated_telemetry_params(payload_as_dict)
            if data:
               data = json.dumps(data)
               # log.info("get_updated_telemetry_params: %s" % data)
               async with aiohttp.ClientSession() as session:
                  loghttp.debug("publisher: http post %s: %s" % (message, data))

                  headers = {"Content-Type": "application/x-www-form-urlencoded"}

                  async with await session.post(
                          "http://127.0.0.1/pub?id=map1", 
                          data=urllib.parse.quote(data),
                          headers=headers) as resp:
                    loghttp.info(await resp.json())

      # else: logmqtt.debug(f"Discarded: {message}")

   logmqtt.debug("fine publisher")

async def read_serial_main(reader, mqtt_queue):
   global serial_queue
   global log
   while True:
      #line = await reader.readline(timeout=3)
      #line = await reader.read(2)
      message = await get_serial_message(reader, serial_queue)
      if message:
          log.info(f"reading from serial: {message}")
          if message.topicname == "justswipedrfidcode":
              await message.react()
          elif message.topicname == "response":
              await message.react()
          else:
              mqtt_queue.put_nowait(message)

async def write_serial_main(writer):
   global serial_queue
   global log
   while True:
      msg = await serial_queue.get()
      pack = msg.pack()
      log.info(f"write_serial_main: {msg} => {pack.hex()}")
      writer.write(pack)
      # writer.transport.flush()

async def serial_main(mqtt_queue):
   global log
   serial_devices=["/dev/ttyS3", "/dev/ttyS0", "/dev/tty"]
   for serial_device in serial_devices:
      try:
         reader, writer = await open_serial_connection(url=serial_device, baudrate=250000) # 115200
         # writer.transport.set_write_buffer_limits(0,0)
      except serial.serialutil.SerialException:
          log.error("SERIAL DEVICE %s NOT AVAILABLE!" % serial_device)
      else:
          break
   else:
       raise Exception("No serial device (among %s) available!" % ", ".join(serial_devices))

   log.info("using device: %s" % serial_device)
   log.debug("remove pending data (if any)... " + (await reader.read(0)).hex()) # throw away pending data
   await asyncio.gather(
           read_serial_main(reader, mqtt_queue),
           write_serial_main(writer)
           )

   log.debug("fine serial")

async def mqtt_task(mqtt_queue):
   global logmqtt
   # Run the advanced_example indefinitely. Reconnect automatically
   # if the connection is lost.
   reconnect_interval = 3  # [seconds]
   logmqtt.info(f"Connecting to broker {BROKER}...")

   while True:
      try:
         async with Client(BROKER) as client:
            # await advanced_example()
            while True:
               await asyncio.gather(
                       subscriber(client),
                       publisher(client, mqtt_queue)
                       )
      except MqttError as error:
         logmqtt.debug(f'Error "{error}". Reconnecting in {reconnect_interval} seconds.')
      finally:
         try:
            await asyncio.sleep(reconnect_interval)
         except RuntimeError:
             pass

async def main():
   global log
   global serial_queue
   log.info("main")
   mqtt_queue = asyncio.Queue()
   serial_queue = asyncio.Queue()

   # >system info is sent via specific requests
   # message_system = SystemInfoMessage()
   # log.debug("%s, %s" % (message_system.topicname, message_system))
   # mqtt_queue.put_nowait(message_system)

   # Schedule three calls *concurrently*:
   await asyncio.gather(
         serial_main(mqtt_queue),
         mqtt_task(mqtt_queue),
         webpage_task(serial_queue),
         startup_routine(serial_queue),
         )
   log.debug("fine main")

# def ctrlz_handler(*args):
#    traceback.print_stack()
#    log.info("Pressed Ctrl-Z: %s" % ''.join(traceback.format_stack()))

# =========================================================================

def initial_program_setup():
   pass

def program_cleanup(*args):
   global log
   log.info("program_cleanup(%s)" % (args,))
   sys.exit(1)

def reload_program_config(*args):
   global log
   log.info("reload_program_config(%s)" % (args,))

async def main_task_cancel(main_task):
   global serial_queue, log
   # 7001: stop dsp when MC is off
   if await send_command_wait_ack(serial_queue, 7001) != "RESPONSE_MESSAGE_OK": # DSP off ?
       # ok DSP is running, sync rfid
       log.warning("DSP not answering 7001!")
   main_task.cancel()

def do_main_program(*args):
   import mylog, logging
   global log, logmqtt, loghttp

   log = logging.getLogger()
   logmqtt = logging.getLogger("root.mqtt")
   loghttp = logging.getLogger("root.http")

   # signal.signal(signal.SIGTSTP, ctrlz_handler)
   # init_log()
   log.info("do_main_program(%s)" % (args,))

   loop = asyncio.get_event_loop()
   main_task = asyncio.ensure_future(main())

   for signal in [SIGUSR1, SIGUSR2]:
       loop.add_signal_handler(signal, manage_signals)

   for signal in [SIGINT, SIGTERM]:
       loop.add_signal_handler(signal, lambda: asyncio.ensure_future(main_task_cancel(main_task)))
   try:
       loop.run_until_complete(main_task)
   except asyncio.exceptions.CancelledError:
       log.debug("fine.")
   except:
       log.exception("fine.")
   finally:
       loop.close()

   # log.debug("bye.")
   # sys.exit(1)

if __name__=='__main__':
    import logging
    # logging.basicConfig(level=logging.NOTSET)
    do_main_program()

