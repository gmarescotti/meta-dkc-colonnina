from enum import IntEnum
import logging

log = logging.getLogger("root.serial")

"""
  serial Events codes
"""
class MqttEvent(IntEnum):
    ERRORE_APERTURA_CHIUSURA_RELAY=0
    ERRORE_STATO_WALLBOX_DURANTE_SELF_TEST=1
    ERRORE_CORRENTE_DI_DISPERSIONE_DC=2
    ERRORE_INTERLOCK=3
    ERRORE_RICHIESTA_RICARICA_CON_VENTILAZIONE=4
    ERRORE_CORTO_CIRCUITO=5
    CORRENTE_DI_RICARICA_RICHIESTA_TROPPO_ALTA=6
    OVER_TEMPERATURE=7
    OVER_VOLTAGE=8
    UNDER_VOLTAGE=9

ENUM_INFO_CHANGE_PWM_STATE = IntEnum("PWM_STATE", "IDLE A1_SWIPE_RFID A1_WAIT_RFID A1_RESET_FACTORY A1 A2 B1 B2 C1 C2 D1 D2 E F F_OVERCURRENT", start=0)
ENUM_INFO_CHANGE_RELAY_STATUS = IntEnum("RELAY_STATUS", "IDLE CLOSING_MAIN OPENING_MAIN CLOSING_SECONDARY OPENING_SECONDARY OPENED CLOSED ERROR", start=0)
ENUM_INFO_CHANGE_LOCK_STATUS = IntEnum("LOCK_STATUS", "IDLE CLOSING OPENING SAFE_OPENING OPENED CLOSED ERROR", start=0)

class SerialEvent(IntEnum):
    INFO_NONE=0
    INFO_BEGIN_MAIN_LOOP=1
    INFO_CHANGE_PWM_STATE=2
    INFO_CHANGE_RELAY_STATUS=3
    INFO_CHANGE_LOCK_STATUS=4
    INFO_CHANGE_LEAKAGE_STATUS=5,
    WARNING_VEHICLE_DONTSTOPCHARGE_AFTERSTOP=6
    ERROR_ASSERT=7
    ERROR_OVERCURRENT=8
    ERROR_SPI=9
    ERROR_I2C=10
    ERROR_LOCK_ENGINE=11
    ERROR_MODBUS=12
    ERROR_CANBUS=13
    ERROR_IDLETIME_LOW=14
    ERROR_IDLETIME_LOST=15
    ERROR_WRONG_SW=16
    ERROR_LEAKAGE=17
    ERROR_VEHICLE_CHARGING=18
    INFO_TEST_LEAKAGE_OK=19
    INFO_RFID_CARD_INSERTED=20
    INFO_USERSTOP_PRESSED=21
    ERROR_OVER_TEMPERATURE=22
    ERROR_OVER_VOLTAGE=23
    ERROR_UNDER_VOLTAGE=24
    ERROR_SHORT_CIRCUIT=25
    ERROR_REQ_VENTILATED_D_STATE=26
    ERROR_RELAY=27
    INFO_RESET_FACTORY_DEFAULT=28

    def toMqttEvent(self, param=None):
        # log.debug(f"toMqttEvent with param {param}")
        maps = {
            # (INFO_BEGIN_MAIN_LOOP, None): None,
            # (INFO_CHANGE_PWM_STATE, None): None,
            (self.INFO_CHANGE_RELAY_STATUS.value, ENUM_INFO_CHANGE_RELAY_STATUS.ERROR): MqttEvent.ERRORE_APERTURA_CHIUSURA_RELAY,
            (self.INFO_CHANGE_LOCK_STATUS.value, ENUM_INFO_CHANGE_LOCK_STATUS.ERROR): MqttEvent.ERRORE_INTERLOCK,
            # (WARNING_VEHICLE_DONTSTOPCHARGE_AFTERSTOP, None): None,
            # (ERROR_ASSERT, None): None,
            (self.ERROR_OVERCURRENT.value, None): MqttEvent.CORRENTE_DI_RICARICA_RICHIESTA_TROPPO_ALTA,
            # (ERROR_SPI, None): None,
            # (ERROR_I2C, None): None,
            # (ERROR_LOCK_ENGINE, None): None,
            # (ERROR_MODBUS, None): None,
            # (ERROR_CANBUS, None): None,
            # (ERROR_IDLETIME_LOW, None): None,
            (self.ERROR_ASSERT.value, None): MqttEvent.ERRORE_STATO_WALLBOX_DURANTE_SELF_TEST,
            (self.ERROR_IDLETIME_LOST.value, None): MqttEvent.ERRORE_STATO_WALLBOX_DURANTE_SELF_TEST,
            (self.ERROR_WRONG_SW.value, None): MqttEvent.ERRORE_STATO_WALLBOX_DURANTE_SELF_TEST,
            (self.ERROR_LOCK_ENGINE.value, None): MqttEvent.ERRORE_STATO_WALLBOX_DURANTE_SELF_TEST,
            (self.ERROR_MODBUS.value, None): MqttEvent.ERRORE_STATO_WALLBOX_DURANTE_SELF_TEST,
            (self.ERROR_CANBUS.value, None): MqttEvent.ERRORE_STATO_WALLBOX_DURANTE_SELF_TEST,
            (self.ERROR_I2C.value, None): MqttEvent.ERRORE_STATO_WALLBOX_DURANTE_SELF_TEST,
            (self.ERROR_SPI.value, None): MqttEvent.ERRORE_STATO_WALLBOX_DURANTE_SELF_TEST,
            (self.ERROR_LEAKAGE.value, None): MqttEvent.ERRORE_CORRENTE_DI_DISPERSIONE_DC,
            # (ERROR_VEHICLE_CHARGING, None): None,
            # (INFO_TEST_LEAKAGE_OK, None): None,
            # (INFO_RFID_CARD_INSERTED, None): None,
            # (INFO_USERSTOP_PRESSED, None): None,
            (self.ERROR_OVER_TEMPERATURE.value, None): MqttEvent.OVER_TEMPERATURE,
            (self.ERROR_OVER_VOLTAGE.value, None): MqttEvent.OVER_VOLTAGE,
            (self.ERROR_UNDER_VOLTAGE.value, None): MqttEvent.UNDER_VOLTAGE,
            (self.ERROR_SHORT_CIRCUIT.value, None): MqttEvent.ERRORE_CORTO_CIRCUITO,
            (self.ERROR_REQ_VENTILATED_D_STATE.value, None): MqttEvent.ERRORE_RICHIESTA_RICARICA_CON_VENTILAZIONE,
        }
        return maps.get((self.value, self.describe(param)), None)

    # return the enum specific of param or the enum itself
    def describe(self, param=None):
        # log.debug(f"describe with param {param}")
        params_dict = {
            self.INFO_CHANGE_PWM_STATE.value: ENUM_INFO_CHANGE_PWM_STATE,
            self.INFO_CHANGE_RELAY_STATUS.value: ENUM_INFO_CHANGE_RELAY_STATUS,
            self.INFO_CHANGE_LOCK_STATUS.value: ENUM_INFO_CHANGE_LOCK_STATUS
            }
        params = params_dict.get(self.value, None)
        # print(params, param, self.name)
        return params(param) if params and param else None

