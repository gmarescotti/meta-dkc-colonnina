"""
CREATE TABLE IF NOT EXISTS 'users' (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, username TEXT UNIQUE, password TEXT, tempo DATETIME,'auth' INTEGER);
CREATE TABLE IF NOT EXISTS 'cards' (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, card_no TEXT UNIQUE, name TEXT, tempo DATETIME, 'status' TEXT DEFAULT 'checked');

import sqlalchemy as db
engine = db.create_engine('sqlite:///access.sqlite')

metadata = db.MetaData()

cards = db.Table('cards', metadata, autoload=True, autoload_with=engine)
users = db.Table('users', metadata, autoload=True, autoload_with=engine)

print(users)
print(users.columns)
rfids = db.Table('rfids', metadata, autoload=True, autoload_with=engine)
cards = db.Table('cards', metadata, autoload=True, autoload_with=engine)
print(cards.columns)
print(repr(metadata.tables['cards']))


[HISTORY COMMAND]
import readline; print('\n'.join([str(readline.get_history_item(i + 1)) for i in range(readline.get_current_history_length())]))


# NON-ORM TYPE
import sqlite3
conn = sqlite3.connect('access.sqlite')
c = conn.cursor()

conn.commit()
conn.close()

"""

if __name__=='__main__':
    import sys, os
    sys.path.append(os.path.abspath(os.path.join('..')))


import os
import sqlalchemy as db
from sqlalchemy import Column, Integer, String, DateTime
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
import scramble

import datetime, pytz
import struct

from .general_message import command

import logging

Base = declarative_base()

log = logging.getLogger("root.sql")

query=None
session=None

class Card(Base):
    __tablename__ = 'cards'

    id = Column(Integer, primary_key=True, autoincrement=True, nullable=False, unique=True)
    card_no = Column(String, unique=True)
    name = Column(String)
    tempo = Column(DateTime)

    def __repr__(self):
       return f"<Card(card_no={self.card_no}, name={self.name}, tempo={self.tempo})>"

def init():
    global query
    global session

    DATABASE="/usr/share/nginx/html/access.sqlite"
    assert os.path.exists(DATABASE)
    #engine = db.create_engine('sqlite:///census.sqlite')
    engine = db.create_engine(f'sqlite:///{DATABASE}')
    # connection = engine.connect()
    # metadata = db.MetaData()
    # cards = db.Table('cards', metadata, autoload=True, autoload_with=engine)
    # ret = db.select([cards])
    # ret = db.select([cards]).where(cards.columns.card_no == card_no)
    # instance = query.first()

    Session = sessionmaker(bind=engine)
    session = Session()
    query = session.query(Card)

def init_old():
    #valutiamo se lasciare creazione automatica tabella alla prima esecuzione
    c.execute('''CREATE TABLE IF NOT EXISTS 'cards' (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, card_no TEXT UNIQUE, name TEXT, tempo DATETIME, 'status' TEXT DEFAULT 'checked');''')

def exists(card_no):
    global query
    ret = query.filter_by(card_no=card_no).first() is not None
    return ret

def print_all():
    global query
    for item in query:
        log.debug (item) # Hello World!
        try:
            encr, decr = _decrypt(item.card_no)
        except Exception as e:
            log.fatal(str(e))
        else:
            print((encr, decr))

def _decrypt(encr):
    if type(encr) is not int:
        encr = int(encr, 16)
    # if type(encr) not in [str, bytes]:
    encr = (encr).to_bytes(12, byteorder='big')
    # else:
    #    encr = bytes(encr, 'utf-8')
    decr = scramble.decrypt(encr)
    length = len(decr)
    if (length > 10) or (length == 0):
        # db_delete_card(encr.hex())
        raise ValueError(f"RFID malformed: {encr}")

    log.debug(f"rfid: length={length}, encr={encr.hex()}, decr={decr.hex()}")
    numof_longs = 1 + ((length-1) >> 2)
    # decr = decr + b"\x00" * ((4 - (len(decr) % 4)) % 4) # Padding zero to be 4 bytes multiple
    # command_params = list(struct.unpack("<" + "L" * numof_longs, decr)) # ">": big endian
    # realsize = length + 4 # add space for id
    return encr, decr # , realsize, command_params

def db_get_all_cards():
    global query
    ret = list()
    for item in query:
        try:
            encr, decr = _decrypt(item.card_no)
        except Exception as e:
            log.fatal(str(e))
        else:
            ret.append((encr, decr))
    return ret

def db_add_card(card_no):
    global session
    if exists(card_no):
        log.error(f"db_add_card: card {card_no} already exists!")
        return
    now = datetime.datetime.now(pytz.timezone('Europe/Rome'))
    ed_user = Card(card_no=card_no, name=card_no, tempo=now)
    session.add(ed_user)
    session.flush()
    session.commit()
    log.debug(f"db_add_card: added card {card_no}")

def db_delete_card(card_no):
    global session
    ret = query.filter_by(card_no=card_no).first()
    if ret is None:
        log.error(f"db_delete_card: card {card_no} not exists!")
        return
    session.delete(ret)
    session.flush()
    session.commit()
    log.debug(f"db_delete: removed card {card_no}")

@command(9002)
def delete_rfid(self, encr):
    log.info(f"Received 9002: {encr}")
    db_delete_card(hex(encr)[2:])
    enc, self.command_params = _decrypt(encr)

@command(9000)
def swipe_rfid_please(self):
    log.info(f"Received 9000")

init()

if __name__=='__main__':
    logging.basicConfig(level=logging.DEBUG)

    ## db_add_card("11111111")

    print_all()
    
    print(exists("a23456789012345678901234"))
    print(exists("a23456789012345678901834"))
    print(exists("a23456789012345678901834"))


