import struct
import logging
from .mydecorator import MyDecorator
import cstruct

SERIAL_MESSAGE_ACK = 3

command=MyDecorator.command

log = logging.getLogger("root.webpage")

ResponseEnum={
        0:"RESPONSE_MESSAGE_OK",
        1:"RESPONSE_MESSAGE_TODO",
        2:"RESPONSE_MESSAGE_FAILED",
        3:"RESPONSE_MESSAGE_PROTOCOL_ERROR",
        4:"RESPONSE_MESSAGE_NOT_APPLICABLE"
}

class GeneralCommands(MyDecorator):
    mp_message_instances = list()
    mp_last_message_counter = 1
    
    def __init__(self, *args, **kwargs):
        self.__dict__.update(*args, **kwargs)
        # id = kwargs.pop("command_id")
        self.run_command(kwargs["command_id"], *kwargs.get("command_params", []))

    # def __str__(self):
    #    return f"{self.topicname}: id={self.command_id}, param=%s" % self.command_param

    def pack(self):
        """
        override pack() because we want to add counter, length and id
        """
        # ret = super().pack()
        # realsize = getattr(self, "realsize", len(ret))
        length = 6 + len(self.content)
        GeneralCommands.mp_last_message_counter += 1
        self.mp_message_counter = GeneralCommands.mp_last_message_counter
        self.mp_message_instances.append(self)
        return struct.pack("3H", 
                self.mp_message_counter, 
                length, 
                self.id) + self.content

# ====================================================
# Acknowledge command of DSP messages
class AckCommandsMessage:
    ack_mp_last_message_counter = 1
    # __struct__ = """
    #         uint32_t command_id_acked;    //! command identifier of acked message
    # """
    id=SERIAL_MESSAGE_ACK

    def __init__(self, command_id):
        self.command_id = command_id

    def pack(self):
        """
        pack() packs counter, length and id
        """
        ret = super().pack()
        length = 6 + len(ret)
        self.ack_mp_last_message_counter += 1
        return struct.pack("3HL", 
                self.ack_mp_last_message_counter, 
                length, 
                self.id,
                self.command_id_acked)

# ====================================================
"""
  serial message SERIAL_MESSAGE_RESPONSE
  contains the response data of the previous command
  0200 0300
"""
class ResponseMessage(cstruct.CStruct):
    topicname="response"
    __byte_order__ = cstruct.LITTLE_ENDIAN
    __struct__ = """
           uint16_t counter;                  // same counter of acked message
           uint16_t response;                 // response code
    """

    async def react(self):
        for msg in GeneralCommands.mp_message_instances:
            if msg.mp_message_counter == self.counter:
                GeneralCommands.mp_message_instances.remove(msg)
                try:
                    await msg.response_callback(ResponseEnum.get(self.response, "???"))
                except:
                    pass
                log.debug(f"react: response {msg} aknowledge!")
                break
            log.warn(f"Warning: forgotten message ({msg.mp_message_counter} < {self.counter}) not acnowledged: {msg}!")
        else:
            log.error(f"react: counter {self.counter} (response={self.response}) not found!")


