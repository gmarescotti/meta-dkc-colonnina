from .general_message import GeneralCommands, command
import struct
from enum import IntEnum
from .serial_protocol import SERIAL_MESSAGE_COMMAND
import logging

logmqtt = logging.getLogger("root.mqtt")

# ====================================================
"""
commands messages structure

to test the commands open shell and execute these commands:

    mosquitto_pub -h "79.7.202.167" -t "DKC/00:00:00:00:00:00/commands" -p 1883 -q 1 -m '{"3013": null}'
    mosquitto_pub -h "79.7.202.167" -t "DKC/00:00:00:00:00:00/commands" -p 1883 -q 1 -m '{"3011": 0}'

"""

class CommandsMessage(GeneralCommands):
    topicname="commands"
    id=SERIAL_MESSAGE_COMMAND

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # self.realsize = (len(self.command_params) * 4) + 4
        self.content = struct.pack("H" + "H" * len(self.command_params), 
                self.command_id, 
                *self.command_params)

"""
3000: Aziona wallbox	int	R/W		
        [0] Start
        [1] Stop
        [2] Pausa
        [3] Riavvia
"""
WallBoxActionType = IntEnum("WALLBOXACTION", "START STOP PAUSE RESTART", start=0)
@command(3000)
def aziona_wallbox(self, op: WallBoxActionType):
    op = WallBoxActionType(int(op))
    logmqtt.info(f"AZIONAMENTO WALLBOX: {op.name}!!!!")

"""
    3001: Prenota wallbox	
    String	R/W		
    Da abbinare ad un codice utente, data, ora
"""
@command(3001)
def prenota_wallbox(self, codice_rfid):
    logmqtt.info(f"PRENOTA WALL BOX PER {codice_rfid}")

"""
3002: Annulla prenotazione	
String	W		
Da abbinare ad un codice utente
"""
@command(3002)
def annulla_prenotazione_wallbox(self, codice_rfid: str):
    logmqtt.info(f"ANNULLA PRENOTAZIONE WALL BOX PER {codice_rfid}")

"""
3004: Aggiungi utente autorizzato	
Bool	R/W		
Occorre avvicinare alla wallbox la relativa RFID card
@param operation: true: aggiunge utente, false: rimuove utente
"""
@command(3004)
def aggiungi_utente_autorizzato(self, operation: bool):
    logmqtt.info(f"AGGIUNGI UTENTE AUTORIZZATO {operation}")

"""
3005: Rimuovi utente autorizzato	
String	W
Da abbinare ad un codice utente
"""
@command(3005)
def rimuovi_utente_autorizzato(self, codice_rfid: str):
    logmqtt.info(f"RIMUOVI UTENTE AUTORIZZATO {codice_rfid}")

"""
3003: Imposta Potenza massima	
Float	R/W	W	
Valore utilizzato anche in caso di selezione del funzionamento con Potenza fissa
"""
@command(3003)
def imposta_potenza_massima(self, potenza: int):
    logmqtt.info(f"POTENZA MASSIMA={potenza}")

"""
3006: Funzionamento Potenza  fissa	
Bool	R/W	W	
    0: Disabilita modalita P fissa
    1: Abilita modalita P fissa
"""
@command(3006)
def funzionamento_potenza_fissa(self, mode_fixed: bool):
    logmqtt.info(f"POTENZA FISSA={mode_fixed}")

"""
3007: Abilita/Disabilita controllo RFID	
Bool	R/W
"""
@command(3007)
def abilita_controllo_rfid(self, enable: bool):
    logmqtt.info(f"CONTROLLO RFID={enable}")

"""
3008: Abilita/Disabilita funzione load balancing	
Bool	R/W
"""
@command(3008)
def abilita_load_balancing(self, enable: bool):
    logmqtt.info(f"ENABLE LOAD BALANCING={enable}")

"""
3009: Abilita/Disabilita OCPP 1.6	
Bool	R/W
"""
@command(3009)
def abilita_ocpp(self, enable: bool):
    logmqtt.info(f"ENABLE OCPP={enable}")

"""
3010: Abilita/Disabilita Modbus	Bool	R/W
"""
@command(3010)
def abilita_modbus(self, enable: bool):
    logmqtt.info(f"ENABLE MODBUS={enable}")

"""
3011	Aggiorna Firmware	Bool	R/W
"""
@command(3011)
def aggiorna_firmware(self, enable: bool):
    logmqtt.info(f"UPDATE FIRMWARE={enable}")

"""
3012	Aggiorna Software	Bool	R/W
"""
@command(3012)
def aggiorna_software(self, enable: bool):
    logmqtt.info(f"UPDATE SOFTWARE={enable}")

"""
3013	Richiedi info	Nessuno	W		
Richiedi invio di INFO
"""
@command(3013)
def richiedi_info(self, *args):
    logmqtt.info(f"RICHIEDI INFO")


