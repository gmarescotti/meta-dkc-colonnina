"""
aggregate all "signals" in this utility class

signals can be:

    1000-1xxx for MqTT commands
    3000-3xxx for DSP commands
    9000-9xxx for Atmel commands
    5000-5xxx for DSP events

"""

class MyDecorator():
    command_functions = dict()
    
    @staticmethod
    def command(*id):
        def decorator(function):
            MyDecorator.command_functions[int(*id)] = function
            return function
        return decorator
    
    def run_command(self, id, *args, **kwargs):
        if id in self.command_functions:
            self.command_functions[id](self, *args, **kwargs)

        # else: print("UUUUUUUUUUUUUUUUUUUUUUUUUUUUU %d, %s" % (id, self.command_functions.keys()))


