#!/usr/bin/env python3

"""
send commands to python daemon through IPyC.
"""

import json
import asyncio
from ipyc import AsyncIPyCClient
import sys

assert len(sys.argv) >= 2, "wrong syntax: call {sys.argv[0]} <comando> <param-0> [<param-1> <param-2> ...]"

async def issue_command():
    client = AsyncIPyCClient()  # Create a client
    link = await client.connect()  # Connect to the host
    # command = dict(command_id=9000, command_param="")
    # command = dict(command_id=int(sys.argv[1]), command_param=int(sys.argv[2]))
    command = dict(command_id=int(sys.argv[1]), command_params=list(map(int, sys.argv[2:])))
    await link.send(json.dumps(command), 'utf-8')  # Send a string
    response = await link.receive()
    print(f"response: {response}")
    # await link.send('{"command_id": 9000, "command_param":""}')
    await client.close()  # Close the connection

def run():
	loop = asyncio.get_event_loop()
	loop.run_until_complete(issue_command())

