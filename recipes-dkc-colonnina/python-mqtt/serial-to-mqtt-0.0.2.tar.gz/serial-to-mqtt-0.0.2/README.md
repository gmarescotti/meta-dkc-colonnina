# SERIAL TO MQTT

program that manages microchip logics for DKC wallbox