import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="serial-to-mqtt", # Replace with your own username
    version="0.0.2",
    author="Giulio Marescotti",
    author_email="giulio.marescotti@rgm.it",
    description="Utilities to manage Wallbox",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://rgm.it/pypa/sampleproject",
    packages=['serial_to_mqtt'],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
    install_requires=[
     'ipyc', 
    ],       
    entry_points={
        'console_scripts': [
          'serial_to_mqtt = serial_to_mqtt.run:run',
          'issue_command = serial_to_mqtt.issue_command:run',
        ],
    },
)
